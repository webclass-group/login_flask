from flask import Flask, render_template, request, redirect, flash, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "secretkey123"

# دیتابیس SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# مدل کاربر
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False)
    city = db.Column(db.String(50), nullable=False)

# ایجاد دیتابیس
with app.app_context():
    db.create_all()

# مسیر پیش‌فرض → ریدایرکت به ثبت نام
@app.route('/')
def home():
    return redirect(url_for('register'))

# ثبت نام
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        role = request.form['role']
        city = request.form['city']

        if User.query.filter_by(username=username).first():
            flash("نام کاربری قبلاً ثبت شده است!", "error")
            return redirect(url_for('register'))

        new_user = User(username=username, password=password, role=role, city=city)
        db.session.add(new_user)
        db.session.commit()
        flash("ثبت نام با موفقیت انجام شد! لطفاً وارد شوید.", "success")
        return redirect(url_for('login'))  # بعد از ثبت نام → صفحه ورود

    return render_template('register.html')

# ورود کاربر
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            flash(f"خوش آمدید {user.username}!", "success")
            return redirect(url_for('users'))
        else:
            flash("نام کاربری یا رمز عبور اشتباه است!", "error")
            return redirect(url_for('login'))

    return render_template('login.html')

# مشاهده کاربران
@app.route('/users')
def users():
    all_users = User.query.all()
    return render_template('users.html', users=all_users)

if __name__ == '__main__':
    app.run(debug=True)

