from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_dance.contrib.google import make_google_blueprint, google

# =========================
# App Config
# =========================
app = Flask(__name__)
app.secret_key = "secret-key-123"

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# =========================
# Google OAuth
# =========================
google_bp = make_google_blueprint(
    client_id="31369739186-oisr19hf5hrhp9ksfi9hg5npv1mhaog6.apps.googleusercontent.com",
    client_secret="PASTE_FULL_CLIENT_SECRET_HERE",
    scope=["profile", "email"],
    redirect_url="/login/google/authorized"
)
app.register_blueprint(google_bp, url_prefix="/login")

# =========================
# Database Model
# =========================
class User(db.Model):
    __tablename__ = "user"

    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(100), nullable=False)
    lastname = db.Column(db.String(100))
    city = db.Column(db.String(100))
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default="user")

with app.app_context():
    db.create_all()

# =========================
# Pages
# =========================
@app.route('/')
@app.route('/login')
def login_page():
    return render_template('login.html')


@app.route('/register')
def register_page():
    return render_template('register.html')


@app.route('/welcome')
def welcome_page():
    if 'user' not in session:
        return redirect('/login')
    return render_template('welcome.html', name=session['user'], role=session['role'])


@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')


# =========================
# API Register
# =========================
@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.form
    user = User(
        firstname=data['firstname'],
        lastname=data.get('lastname', ''),
        city=data.get('city', ''),
        password=generate_password_hash(data['password']),
        role=data.get('role', 'user')
    )
    db.session.add(user)
    db.session.commit()
    return redirect('/login')


# =========================
# API Login (Normal)
# =========================
@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.form
    user = User.query.filter_by(firstname=data['username']).first()

    if user and check_password_hash(user.password, data['password']):
        session['user'] = user.firstname
        session['role'] = user.role
        return redirect('/welcome')

    return redirect('/login')


# =========================
# Google Login
# =========================
@app.route('/login/google')
def google_login():
    if not google.authorized:
        return redirect(url_for("google.login"))

    info = google.get("/oauth2/v2/userinfo").json()
    email = info["email"]

    user = User.query.filter_by(firstname=email).first()
    if not user:
        user = User(
            firstname=email,
            lastname=info.get("family_name", ""),
            city="Google",
            password="google",
            role="user"
        )
        db.session.add(user)
        db.session.commit()

    session['user'] = user.firstname
    session['role'] = user.role
    return redirect('/welcome')

# =========================
# مسیر نمایش صفحه کاربران
# =========================
@app.route('/users')
def users_page():
    # امنیت: چک کردن اینکه آیا کاربر وارد شده و ادمین است
    if 'user' not in session or session.get('role') != 'admin':
        return redirect('/login')
    return render_template('users.html')

# =========================
# API برای دریافت لیست کاربران بصورت JSON
# =========================
@app.route('/api/users')
def api_users():
    # امنیت: فقط ادمین اجازه دسترسی به داده‌های خام را داشته باشد
    if 'user' not in session or session.get('role') != 'admin':
        return jsonify({"error": "Unauthorized"}), 403
        
    users = User.query.all()
    output = []
    for user in users:
        user_data = {
            'firstname': user.firstname,
            'lastname': user.lastname,
            'city': user.city,
            'role': user.role
        }
        output.append(user_data)
    
    return jsonify(output)

# =========================
# Run Server
# =========================
if __name__ == '__main__':
    app.run(debug=True)
